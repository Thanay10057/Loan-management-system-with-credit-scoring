// 1. Customer
export interface Customer {
  Customer_ID: string;
  Full_Name: string;
  Date_of_Birth: string;
  PAN_Number: string;
  Aadhaar_Number: string;
  Email: string;
  Phone: string;
  Address: string;
  Employment_Type: 'Salaried' | 'Self-Employed';
  Annual_Income: number;
  Account_Status: 'Active' | 'Suspended';
}

// 2. Credit_Score
export interface CreditScore {
  Credit_ID: string;
  Customer_ID: string;
  Credit_Score_Value: number;
  Credit_Rating: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  Last_Updated: string;
}

// 3. Loan_Type
export interface LoanType {
  Loan_Type_ID: string;
  Loan_Name: 'Home Loan' | 'Personal Loan' | 'Education Loan';
  Interest_Rate: number; // Annual percentage
  Max_Loan_Amount: number;
  Min_Credit_Score: number;
  Max_Tenure_Months: number;
  Description: string;
}

// 4. Loan_Application
export interface LoanApplication {
  Application_ID: string;
  Customer_ID: string;
  Loan_Type_ID: string;
  Requested_Amount: number;
  Requested_Tenure: number;
  Application_Date: string;
  Application_Status: 'Pending' | 'Approved' | 'Rejected';
  Rejection_Reason?: string;
}

// 5. Loan
export interface Loan {
  Loan_ID: string;
  Application_ID: string;
  Customer_ID: string; // Added for easier querying
  Loan_Type_ID: string; // Added for display
  Approved_Amount: number;
  Interest_Rate: number;
  Tenure_Months: number;
  Loan_Start_Date: string;
  Loan_End_Date: string;
  Loan_Status: 'Active' | 'Closed' | 'Defaulted';
}

// 6. EMI_Schedule
export interface EMISchedule {
  EMI_ID: string;
  Loan_ID: string;
  EMI_Number: number;
  EMI_Amount: number;
  Due_Date: string;
  Payment_Status: 'Pending' | 'Paid' | 'Overdue';
}

// 7. Payment
export interface Payment {
  Payment_ID: string;
  EMI_ID: string;
  Payment_Date: string;
  Amount_Paid: number;
  Payment_Mode: 'UPI' | 'NetBanking' | 'Cash';
  Payment_Status: 'Success' | 'Failed';
}

// 8. Bank_Account
export interface BankAccount {
  Account_ID: string;
  Customer_ID: string;
  Account_Number: string;
  Account_Type: 'Savings' | 'Current';
  Balance: number;
  IFSC_Code: string;
}

// 9. Loan_Approval_Log
export interface LoanApprovalLog {
  Approval_ID: string;
  Application_ID: string;
  Approved_By: string;
  Approval_Date: string;
  Remarks: string;
  Decision: 'Approved' | 'Rejected';
}

// Application State Helper
export type ViewState = 'DASHBOARD' | 'APPLY_LOAN' | 'MY_LOANS' | 'OFFICER_PORTAL' | 'PROFILE';

export interface AppData {
  currentUser: Customer;
  bankAccount: BankAccount;
  creditScore: CreditScore;
  loanTypes: LoanType[];
  applications: LoanApplication[];
  loans: Loan[];
  emiSchedules: EMISchedule[];
  payments: Payment[];
  approvalLogs: LoanApprovalLog[];
}