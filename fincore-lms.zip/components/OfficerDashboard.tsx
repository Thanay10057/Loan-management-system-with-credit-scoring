import React, { useState } from 'react';
import { AppData } from '../types';
import { Check, X, Eye } from 'lucide-react';

interface Props {
  data: AppData;
  onApprove: (appId: string, remarks: string) => void;
  onReject: (appId: string, reason: string) => void;
}

export const OfficerDashboard: React.FC<Props> = ({ data, onApprove, onReject }) => {
  const pendingApps = data.applications.filter(a => a.Application_Status === 'Pending');
  const [selectedAppId, setSelectedAppId] = useState<string | null>(null);
  const [remarks, setRemarks] = useState('');

  const selectedApp = data.applications.find(a => a.Application_ID === selectedAppId);
  const selectedUser = selectedApp ? data.currentUser : null; // In real app, fetch specific user
  const selectedLoanType = selectedApp ? data.loanTypes.find(t => t.Loan_Type_ID === selectedApp.Loan_Type_ID) : null;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-slate-800">Officer Portal - Loan Approvals</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* List of Pending */}
        <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 bg-slate-50 border-b border-slate-200">
             <h3 className="font-semibold text-slate-700">Pending Requests ({pendingApps.length})</h3>
          </div>
          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {pendingApps.length === 0 && (
              <div className="p-6 text-center text-slate-400 text-sm">No pending applications.</div>
            )}
            {pendingApps.map(app => (
              <div 
                key={app.Application_ID} 
                onClick={() => { setSelectedAppId(app.Application_ID); setRemarks(''); }}
                className={`p-4 cursor-pointer hover:bg-slate-50 transition-colors ${selectedAppId === app.Application_ID ? 'bg-blue-50 border-l-4 border-blue-500' : ''}`}
              >
                <div className="flex justify-between items-start mb-1">
                   <span className="font-medium text-slate-800">${app.Requested_Amount.toLocaleString()}</span>
                   <span className="text-xs text-slate-500">{app.Application_Date}</span>
                </div>
                <div className="flex items-center gap-2">
                   <span className="text-xs px-2 py-0.5 bg-slate-200 rounded text-slate-600">
                     {data.loanTypes.find(t => t.Loan_Type_ID === app.Loan_Type_ID)?.Loan_Name}
                   </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed Review View */}
        <div className="lg:col-span-2">
          {selectedApp && selectedUser && selectedLoanType ? (
            <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
               <div className="flex justify-between items-start mb-6 border-b border-slate-100 pb-4">
                 <div>
                   <h3 className="text-xl font-bold text-slate-800">Application Review</h3>
                   <p className="text-sm text-slate-500">App ID: {selectedApp.Application_ID}</p>
                 </div>
                 <div className="text-right">
                   <span className={`text-xl font-bold ${data.creditScore.Credit_Score_Value >= 700 ? 'text-emerald-600' : 'text-amber-600'}`}>
                     Score: {data.creditScore.Credit_Score_Value}
                   </span>
                   <p className="text-xs text-slate-500">Credit Rating</p>
                 </div>
               </div>

               <div className="grid grid-cols-2 gap-6 mb-8">
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Applicant</p>
                    <p className="text-slate-800 font-medium">{selectedUser.Full_Name}</p>
                    <p className="text-sm text-slate-600">{selectedUser.Employment_Type}, Income: ${selectedUser.Annual_Income.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Loan Details</p>
                    <p className="text-slate-800 font-medium">{selectedLoanType.Loan_Name}</p>
                    <p className="text-sm text-slate-600">
                      ${selectedApp.Requested_Amount.toLocaleString()} for {selectedApp.Requested_Tenure} months
                    </p>
                  </div>
               </div>

               <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 mb-6">
                 <label className="block text-sm font-medium text-slate-700 mb-2">Officer Remarks / Rejection Reason</label>
                 <textarea 
                   className="w-full p-3 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 outline-none"
                   rows={3}
                   placeholder="Enter notes here..."
                   value={remarks}
                   onChange={(e) => setRemarks(e.target.value)}
                 ></textarea>
               </div>

               <div className="flex gap-4">
                 <button 
                   onClick={() => onApprove(selectedApp.Application_ID, remarks || 'Approved based on eligibility.')}
                   className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2"
                 >
                   <Check className="w-5 h-5" /> Approve Loan
                 </button>
                 <button 
                   onClick={() => onReject(selectedApp.Application_ID, remarks || 'Policy criteria mismatch.')}
                   className="flex-1 bg-rose-600 hover:bg-rose-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center gap-2"
                 >
                   <X className="w-5 h-5" /> Reject Application
                 </button>
               </div>
            </div>
          ) : (
             <div className="h-full bg-slate-50 rounded-xl border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400">
               <Eye className="w-12 h-12 mb-2 opacity-50" />
               <p>Select an application to review</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};