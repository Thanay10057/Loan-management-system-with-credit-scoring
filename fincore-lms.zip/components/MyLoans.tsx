import React, { useState } from 'react';
import { AppData, EMISchedule } from '../types';
import { Calendar, ChevronRight, CheckCircle2, CreditCard, Wallet, Loader2, XCircle } from 'lucide-react';
import { processPaymentWithGateway } from '../services/db';

interface Props {
  data: AppData;
  onPayEMI: (emiId: string, mode: 'UPI' | 'NetBanking' | 'Cash') => void;
}

export const MyLoans: React.FC<Props> = ({ data, onPayEMI }) => {
  const [selectedLoanId, setSelectedLoanId] = useState<string | null>(data.loans.length > 0 ? data.loans[0].Loan_ID : null);
  
  // Payment Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEMI, setSelectedEMI] = useState<EMISchedule | null>(null);
  const [paymentMode, setPaymentMode] = useState<'UPI' | 'NetBanking' | 'Cash'>('UPI');
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'failed'>('idle');
  const [statusMessage, setStatusMessage] = useState('');

  const activeLoan = data.loans.find(l => l.Loan_ID === selectedLoanId);
  const relatedEMIs = selectedLoanId 
    ? data.emiSchedules.filter(e => e.Loan_ID === selectedLoanId).sort((a,b) => a.EMI_Number - b.EMI_Number) 
    : [];

  const nextDueEMI = relatedEMIs.find(e => e.Payment_Status !== 'Paid');

  const initiatePayment = (emi: EMISchedule) => {
    setSelectedEMI(emi);
    setPaymentStatus('idle');
    setPaymentMode('UPI');
    setIsModalOpen(true);
  };

  const confirmPayment = async () => {
    if (!selectedEMI) return;

    setPaymentStatus('processing');
    try {
      // Call mock gateway
      const result = await processPaymentWithGateway(selectedEMI.EMI_Amount, paymentMode);
      
      if (result.success) {
        setPaymentStatus('success');
        setStatusMessage(result.message);
        
        // Wait a bit to show success state before updating app state and closing
        setTimeout(() => {
          onPayEMI(selectedEMI.EMI_ID, paymentMode);
          setIsModalOpen(false);
        }, 1500);
      } else {
        setPaymentStatus('failed');
        setStatusMessage(result.message);
      }
    } catch (error) {
      setPaymentStatus('failed');
      setStatusMessage("Unexpected Gateway Error");
    }
  };

  return (
    <div className="space-y-6 relative">
      <h2 className="text-2xl font-bold text-slate-800">My Loans & Repayments</h2>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Loan Selector */}
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-slate-500 uppercase">Active Accounts</h3>
          {data.loans.length === 0 ? (
            <p className="text-slate-500 italic">No active loans.</p>
          ) : (
            data.loans.map(loan => (
              <div 
                key={loan.Loan_ID}
                onClick={() => setSelectedLoanId(loan.Loan_ID)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedLoanId === loan.Loan_ID 
                  ? 'bg-slate-800 text-white border-slate-800 shadow-lg' 
                  : 'bg-white border-slate-200 hover:border-slate-400'
                }`}
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="font-bold text-lg">
                    {data.loanTypes.find(t => t.Loan_Type_ID === loan.Loan_Type_ID)?.Loan_Name}
                  </span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    loan.Loan_Status === 'Active' ? 'bg-emerald-500/20 text-emerald-500' : 'bg-slate-500/20 text-slate-300'
                  }`}>
                    {loan.Loan_Status}
                  </span>
                </div>
                <div className="flex justify-between text-sm opacity-80">
                  <span>${loan.Approved_Amount.toLocaleString()}</span>
                  <span>{loan.Interest_Rate}% APR</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* EMI Details */}
        <div className="lg:col-span-2">
          {activeLoan ? (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                 <div>
                   <h3 className="font-bold text-slate-800">Repayment Schedule</h3>
                   <p className="text-xs text-slate-500">Loan ID: {activeLoan.Loan_ID}</p>
                 </div>
                 {nextDueEMI && (
                   <div className="text-right">
                     <p className="text-xs text-slate-500 uppercase font-bold">Next Due</p>
                     <p className="text-rose-600 font-bold">{nextDueEMI.Due_Date}</p>
                   </div>
                 )}
              </div>

              <div className="max-h-[500px] overflow-y-auto">
                <table className="w-full text-sm text-left">
                  <thead className="bg-white sticky top-0 shadow-sm z-10 text-slate-500">
                    <tr>
                      <th className="p-4">#</th>
                      <th className="p-4">Due Date</th>
                      <th className="p-4">Amount</th>
                      <th className="p-4">Status</th>
                      <th className="p-4">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {relatedEMIs.map((emi) => (
                      <tr key={emi.EMI_ID} className="hover:bg-slate-50 transition-colors">
                        <td className="p-4 text-slate-400">{emi.EMI_Number}</td>
                        <td className="p-4 flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          {emi.Due_Date}
                        </td>
                        <td className="p-4 font-medium text-slate-800">${emi.EMI_Amount.toLocaleString()}</td>
                        <td className="p-4">
                          {emi.Payment_Status === 'Paid' ? (
                            <span className="flex items-center gap-1 text-emerald-600 font-medium">
                              <CheckCircle2 className="w-4 h-4" /> Paid
                            </span>
                          ) : emi.Payment_Status === 'Overdue' ? (
                             <span className="text-rose-600 font-bold">Overdue</span>
                          ) : (
                             <span className="text-amber-600 font-medium">Pending</span>
                          )}
                        </td>
                        <td className="p-4">
                          {emi.Payment_Status !== 'Paid' && (
                            <button
                              onClick={() => initiatePayment(emi)}
                              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-semibold shadow-sm transition-all"
                            >
                              Pay Now
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
               <ChevronRight className="w-8 h-8 mb-2" />
               <p>Select a loan to view schedule</p>
            </div>
          )}
        </div>
      </div>

      {/* Payment Gateway Modal */}
      {isModalOpen && selectedEMI && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Wallet className="w-5 h-5 text-indigo-600" /> Secure Payment Gateway
              </h3>
              {paymentStatus !== 'processing' && (
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                  <XCircle className="w-6 h-6" />
                </button>
              )}
            </div>

            <div className="p-6">
              {paymentStatus === 'idle' && (
                <>
                  <div className="mb-6">
                    <p className="text-sm text-slate-500 mb-1">Payment Amount</p>
                    <p className="text-3xl font-bold text-slate-800">${selectedEMI.EMI_Amount.toLocaleString()}</p>
                    <p className="text-xs text-slate-400 mt-1">For EMI #{selectedEMI.EMI_Number}</p>
                  </div>

                  <div className="mb-6 space-y-3">
                    <label className="text-sm font-medium text-slate-700 block">Select Payment Method</label>
                    <div 
                      onClick={() => setPaymentMode('UPI')}
                      className={`p-3 border rounded-lg cursor-pointer flex items-center gap-3 transition-all ${paymentMode === 'UPI' ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600' : 'border-slate-200 hover:border-slate-300'}`}
                    >
                       <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center text-xs font-bold text-slate-600">UPI</div>
                       <span className="font-medium text-slate-700">UPI / VPA</span>
                    </div>
                    <div 
                      onClick={() => setPaymentMode('NetBanking')}
                      className={`p-3 border rounded-lg cursor-pointer flex items-center gap-3 transition-all ${paymentMode === 'NetBanking' ? 'border-indigo-600 bg-indigo-50 ring-1 ring-indigo-600' : 'border-slate-200 hover:border-slate-300'}`}
                    >
                       <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center"><CreditCard className="w-4 h-4 text-slate-600" /></div>
                       <span className="font-medium text-slate-700">NetBanking</span>
                    </div>
                  </div>

                  <button 
                    onClick={confirmPayment}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-bold shadow-lg shadow-indigo-200 transition-all flex items-center justify-center gap-2"
                  >
                    Pay ${selectedEMI.EMI_Amount.toLocaleString()}
                  </button>
                </>
              )}

              {paymentStatus === 'processing' && (
                <div className="py-8 flex flex-col items-center justify-center text-center">
                  <Loader2 className="w-16 h-16 text-indigo-600 animate-spin mb-4" />
                  <h4 className="text-xl font-bold text-slate-800">Processing Payment</h4>
                  <p className="text-slate-500 mt-2">Connecting to secure gateway...</p>
                  <p className="text-xs text-slate-400 mt-4">Do not close this window</p>
                </div>
              )}

              {paymentStatus === 'success' && (
                <div className="py-8 flex flex-col items-center justify-center text-center animate-fade-in-up">
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-10 h-10 text-emerald-600" />
                  </div>
                  <h4 className="text-xl font-bold text-emerald-800">Payment Successful!</h4>
                  <p className="text-emerald-600 mt-2">{statusMessage}</p>
                </div>
              )}

              {paymentStatus === 'failed' && (
                <div className="py-8 flex flex-col items-center justify-center text-center animate-shake">
                   <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                    <XCircle className="w-10 h-10 text-red-600" />
                  </div>
                  <h4 className="text-xl font-bold text-red-800">Payment Failed</h4>
                  <p className="text-red-600 mt-2">{statusMessage}</p>
                  <button 
                    onClick={() => setPaymentStatus('idle')}
                    className="mt-6 px-6 py-2 bg-slate-800 text-white rounded-lg text-sm"
                  >
                    Try Again
                  </button>
                </div>
              )}
            </div>
            
            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-center">
               <p className="text-[10px] text-slate-400 uppercase tracking-wider flex items-center gap-1">
                 <ShieldCheck className="w-3 h-3" /> 256-bit SSL Encrypted
               </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Quick helper for the SSL icon since I missed importing it in MyLoans
const ShieldCheck = ({className}: {className?: string}) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" /><path d="m9 12 2 2 4-4" /></svg>
);
