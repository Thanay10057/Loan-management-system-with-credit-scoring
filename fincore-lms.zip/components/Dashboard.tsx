import React from 'react';
import { AppData } from '../types';
import { CreditCard, TrendingUp, Wallet, AlertCircle } from 'lucide-react';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

interface DashboardProps {
  data: AppData;
}

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const { currentUser, creditScore, bankAccount, loans, emiSchedules } = data;

  // Calculate some aggregate stats
  const totalLoanValue = loans.reduce((acc, loan) => acc + loan.Approved_Amount, 0);
  const pendingEMIs = emiSchedules.filter(emi => emi.Payment_Status !== 'Paid').length;
  const nextEMIDate = emiSchedules
    .filter(emi => emi.Payment_Status === 'Pending')
    .sort((a, b) => new Date(a.Due_Date).getTime() - new Date(b.Due_Date).getTime())[0]?.Due_Date || 'No active dues';

  // Chart Data
  const loanDistribution = loans.map(l => ({
    name: data.loanTypes.find(t => t.Loan_Type_ID === l.Loan_Type_ID)?.Loan_Name || 'Loan',
    value: l.Approved_Amount
  }));

  const COLORS = ['#059669', '#0891b2', '#4f46e5', '#ca8a04'];

  return (
    <div className="space-y-6">
      <header className="mb-8">
        <h2 className="text-3xl font-bold text-slate-800">Welcome back, {currentUser.Full_Name.split(' ')[0]}</h2>
        <p className="text-slate-500">Here's your financial overview for today.</p>
      </header>

      {/* Stat Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Account Balance</span>
            <div className="p-2 bg-blue-50 rounded-lg"><Wallet className="w-5 h-5 text-blue-600" /></div>
          </div>
          <span className="text-3xl font-bold text-slate-800">${bankAccount.Balance.toLocaleString()}</span>
          <span className="text-xs text-slate-400 mt-2">{bankAccount.Account_Number}</span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Credit Score</span>
            <div className={`p-2 rounded-lg ${creditScore.Credit_Score_Value >= 750 ? 'bg-emerald-50' : 'bg-amber-50'}`}>
               <TrendingUp className={`w-5 h-5 ${creditScore.Credit_Score_Value >= 750 ? 'text-emerald-600' : 'text-amber-600'}`} />
            </div>
          </div>
          <span className={`text-3xl font-bold ${creditScore.Credit_Score_Value >= 750 ? 'text-emerald-600' : 'text-amber-600'}`}>
            {creditScore.Credit_Score_Value}
          </span>
          <span className="text-xs text-slate-400 mt-2">Rating: {creditScore.Credit_Rating}</span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Active Loans Value</span>
            <div className="p-2 bg-indigo-50 rounded-lg"><CreditCard className="w-5 h-5 text-indigo-600" /></div>
          </div>
          <span className="text-3xl font-bold text-slate-800">${totalLoanValue.toLocaleString()}</span>
          <span className="text-xs text-slate-400 mt-2">{loans.filter(l => l.Loan_Status === 'Active').length} Active Accounts</span>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <span className="text-slate-500 text-sm font-medium">Next EMI Due</span>
            <div className="p-2 bg-rose-50 rounded-lg"><AlertCircle className="w-5 h-5 text-rose-600" /></div>
          </div>
          <span className="text-xl font-bold text-slate-800">{nextEMIDate}</span>
          <span className="text-xs text-slate-400 mt-2">{pendingEMIs} Pending Payments</span>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
           <h3 className="text-lg font-semibold text-slate-800 mb-4">Loan Distribution</h3>
           {loans.length > 0 ? (
             <div className="h-64">
               <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                   <Pie
                     data={loanDistribution}
                     cx="50%"
                     cy="50%"
                     innerRadius={60}
                     outerRadius={80}
                     fill="#8884d8"
                     paddingAngle={5}
                     dataKey="value"
                   >
                     {loanDistribution.map((entry, index) => (
                       <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                     ))}
                   </Pie>
                   <Tooltip />
                 </PieChart>
               </ResponsiveContainer>
             </div>
           ) : (
             <div className="h-64 flex items-center justify-center text-slate-400">No active loans</div>
           )}
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Repayment History</h3>
          <div className="h-64 flex items-center justify-center text-slate-400 bg-slate-50 rounded-lg border border-dashed border-slate-200">
             {/* Mock chart since we might not have much history initially */}
             <span className="text-sm">Start making payments to see trends</span>
          </div>
        </div>
      </div>
    </div>
  );
};