import React, { useState } from 'react';
import { AppData, LoanApplication } from '../types';
import { calculateEMI, checkEligibility } from '../services/db';
import { AlertTriangle, CheckCircle, XCircle, Calculator } from 'lucide-react';

interface Props {
  data: AppData;
  onSubmit: (app: LoanApplication) => void;
}

export const LoanApplicationForm: React.FC<Props> = ({ data, onSubmit }) => {
  const [selectedType, setSelectedType] = useState(data.loanTypes[0].Loan_Type_ID);
  const [amount, setAmount] = useState<number>(100000);
  const [tenure, setTenure] = useState<number>(12);
  const [checkResult, setCheckResult] = useState<{ eligible: boolean; reason?: string } | null>(null);

  const currentLoanType = data.loanTypes.find(t => t.Loan_Type_ID === selectedType)!;
  const estimatedEMI = calculateEMI(amount, currentLoanType.Interest_Rate, tenure);

  const handleCheckEligibility = () => {
    // Construct a temporary app object for checking
    const tempApp: LoanApplication = {
      Application_ID: 'TEMP',
      Customer_ID: data.currentUser.Customer_ID,
      Loan_Type_ID: selectedType,
      Requested_Amount: amount,
      Requested_Tenure: tenure,
      Application_Date: new Date().toISOString(),
      Application_Status: 'Pending'
    };
    
    const result = checkEligibility(tempApp, data.creditScore, currentLoanType, data.currentUser);
    setCheckResult(result);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkResult?.eligible) return;

    const newApp: LoanApplication = {
      Application_ID: `APP-${Date.now()}`,
      Customer_ID: data.currentUser.Customer_ID,
      Loan_Type_ID: selectedType,
      Requested_Amount: amount,
      Requested_Tenure: tenure,
      Application_Date: new Date().toISOString().split('T')[0],
      Application_Status: 'Pending'
    };
    onSubmit(newApp);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 p-6 text-white">
          <h2 className="text-2xl font-bold">New Loan Application</h2>
          <p className="text-slate-300 text-sm mt-1">Fill in the details below to request funding.</p>
        </div>

        <div className="p-8 space-y-8">
          {/* Step 3: Selection */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Loan Product</label>
              <select 
                value={selectedType} 
                onChange={(e) => { setSelectedType(e.target.value); setCheckResult(null); }}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
              >
                {data.loanTypes.map(t => (
                  <option key={t.Loan_Type_ID} value={t.Loan_Type_ID}>{t.Loan_Name} ({t.Interest_Rate}% APR)</option>
                ))}
              </select>
              <p className="text-xs text-slate-500 mt-2">{currentLoanType.Description}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Loan Tenure (Months)</label>
              <input 
                type="number" 
                min="6"
                max={currentLoanType.Max_Tenure_Months}
                value={tenure}
                onChange={(e) => { setTenure(Number(e.target.value)); setCheckResult(null); }}
                className="w-full p-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none"
              />
              <p className="text-xs text-slate-500 mt-2">Max: {currentLoanType.Max_Tenure_Months} months</p>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">Requested Amount</label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-slate-400">$</span>
                <input 
                  type="number" 
                  min="1000"
                  step="1000"
                  max={currentLoanType.Max_Loan_Amount}
                  value={amount}
                  onChange={(e) => { setAmount(Number(e.target.value)); setCheckResult(null); }}
                  className="w-full p-3 pl-8 border border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 outline-none font-semibold text-lg"
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">Max eligible: ${currentLoanType.Max_Loan_Amount.toLocaleString()}</p>
            </div>
          </div>

          {/* EMI Preview */}
          <div className="bg-slate-50 p-4 rounded-lg flex items-center justify-between border border-slate-200">
            <div className="flex items-center gap-3">
              <Calculator className="w-6 h-6 text-slate-500" />
              <div>
                <p className="text-xs text-slate-500 uppercase font-bold">Estimated EMI</p>
                <p className="text-xl font-bold text-slate-800">${estimatedEMI.toLocaleString()}/mo</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-slate-500">Total Interest</p>
              <p className="text-sm font-medium text-slate-700">
                ${((estimatedEMI * tenure) - amount).toLocaleString()}
              </p>
            </div>
          </div>

          {/* Step 4: Eligibility Check */}
          {checkResult === null ? (
            <button 
              onClick={handleCheckEligibility}
              className="w-full py-4 bg-slate-800 hover:bg-slate-700 text-white rounded-lg font-semibold transition-colors flex items-center justify-center gap-2"
            >
              Check Eligibility
            </button>
          ) : (
            <div className={`p-4 rounded-lg border ${checkResult.eligible ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
              <div className="flex items-start gap-3">
                {checkResult.eligible ? <CheckCircle className="w-6 h-6 text-emerald-600" /> : <XCircle className="w-6 h-6 text-red-600" />}
                <div>
                  <h4 className={`font-bold ${checkResult.eligible ? 'text-emerald-800' : 'text-red-800'}`}>
                    {checkResult.eligible ? 'You are Eligible!' : 'Eligibility Check Failed'}
                  </h4>
                  {!checkResult.eligible && (
                    <p className="text-sm text-red-600 mt-1">{checkResult.reason}</p>
                  )}
                  {checkResult.eligible && (
                    <div className="mt-4">
                      <p className="text-sm text-emerald-700 mb-4">You meet all the criteria for this loan product.</p>
                      <button 
                        onClick={handleSubmit}
                        className="px-6 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium transition-colors"
                      >
                        Submit Application
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-slate-800 mb-4">Recent Applications</h3>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
           <table className="w-full text-left text-sm">
             <thead className="bg-slate-50 border-b border-slate-200 text-slate-500">
                <tr>
                  <th className="p-4">App ID</th>
                  <th className="p-4">Date</th>
                  <th className="p-4">Amount</th>
                  <th className="p-4">Status</th>
                </tr>
             </thead>
             <tbody>
               {data.applications.length === 0 ? (
                 <tr><td colSpan={4} className="p-8 text-center text-slate-400">No applications yet</td></tr>
               ) : (
                 data.applications.map(app => (
                   <tr key={app.Application_ID} className="border-b border-slate-100">
                     <td className="p-4 font-mono text-xs">{app.Application_ID}</td>
                     <td className="p-4">{app.Application_Date}</td>
                     <td className="p-4 font-medium">${app.Requested_Amount.toLocaleString()}</td>
                     <td className="p-4">
                       <span className={`px-2 py-1 rounded-full text-xs font-bold
                         ${app.Application_Status === 'Approved' ? 'bg-emerald-100 text-emerald-700' : 
                           app.Application_Status === 'Rejected' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                         }
                       `}>
                         {app.Application_Status}
                       </span>
                     </td>
                   </tr>
                 ))
               )}
             </tbody>
           </table>
        </div>
      </div>
    </div>
  );
};