import React from 'react';
import { 
  LayoutDashboard, 
  BadgeDollarSign, 
  Briefcase, 
  User, 
  LogOut,
  Landmark,
  ShieldCheck
} from 'lucide-react';
import { ViewState, Customer } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentView: ViewState;
  setView: (view: ViewState) => void;
  user: Customer;
  isAdminMode: boolean;
  toggleAdminMode: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, currentView, setView, user, isAdminMode, toggleAdminMode 
}) => {
  
  const navItemClass = (view: ViewState) => `
    flex items-center gap-3 px-4 py-3 rounded-lg cursor-pointer transition-colors duration-200
    ${currentView === view 
      ? 'bg-emerald-600 text-white shadow-md' 
      : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
  `;

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col shadow-xl z-20">
        <div className="p-6 border-b border-slate-800 flex items-center gap-3">
          <div className="bg-emerald-500 p-2 rounded-lg">
            <Landmark className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">FinCore</h1>
            <p className="text-xs text-slate-400">Loan Management</p>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {!isAdminMode && (
            <>
              <div onClick={() => setView('DASHBOARD')} className={navItemClass('DASHBOARD')}>
                <LayoutDashboard className="w-5 h-5" />
                <span className="font-medium">Overview</span>
              </div>
              <div onClick={() => setView('APPLY_LOAN')} className={navItemClass('APPLY_LOAN')}>
                <BadgeDollarSign className="w-5 h-5" />
                <span className="font-medium">Apply for Loan</span>
              </div>
              <div onClick={() => setView('MY_LOANS')} className={navItemClass('MY_LOANS')}>
                <Briefcase className="w-5 h-5" />
                <span className="font-medium">My Loans & EMI</span>
              </div>
              <div onClick={() => setView('PROFILE')} className={navItemClass('PROFILE')}>
                <User className="w-5 h-5" />
                <span className="font-medium">My Profile</span>
              </div>
            </>
          )}

          {isAdminMode && (
            <div onClick={() => setView('OFFICER_PORTAL')} className={navItemClass('OFFICER_PORTAL')}>
              <ShieldCheck className="w-5 h-5" />
              <span className="font-medium">Officer Portal</span>
            </div>
          )}
        </nav>

        <div className="p-4 border-t border-slate-800">
           <div className="bg-slate-800 rounded-lg p-3 mb-4">
              <p className="text-xs text-slate-400 uppercase font-bold mb-1">Current User</p>
              <p className="text-sm font-semibold truncate">{isAdminMode ? 'Bank Officer' : user.Full_Name}</p>
              <p className="text-xs text-emerald-400 mt-1">{isAdminMode ? 'Admin Access' : user.Account_Status}</p>
           </div>

           <button 
             onClick={toggleAdminMode}
             className="w-full flex items-center justify-center gap-2 py-2 text-sm text-slate-400 hover:text-white transition-colors"
           >
             <LogOut className="w-4 h-4" />
             Switch to {isAdminMode ? 'Customer' : 'Officer'}
           </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative">
        <div className="max-w-7xl mx-auto p-8 pb-24">
            {children}
        </div>
      </main>
    </div>
  );
};