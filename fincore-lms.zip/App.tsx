import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { LoanApplicationForm } from './components/LoanApplicationForm';
import { OfficerDashboard } from './components/OfficerDashboard';
import { MyLoans } from './components/MyLoans';
import { AIAssistant } from './components/AIAssistant';
import { db } from './services/db';
import { AppData, ViewState, LoanApplication } from './types';

function App() {
  const [currentView, setCurrentView] = useState<ViewState>('DASHBOARD');
  const [data, setData] = useState<AppData>(db.get());
  const [isAdminMode, setIsAdminMode] = useState(false);

  // --- Actions ---

  const handleCreateApplication = (app: LoanApplication) => {
    const updatedApps = [...data.applications, app];
    const newData = db.update({ applications: updatedApps });
    setData(newData);
    // After apply, go to Dashboard
    setCurrentView('DASHBOARD');
  };

  const handleApproveLoan = (appId: string, remarks: string) => {
    const app = data.applications.find(a => a.Application_ID === appId);
    if (!app) return;
    
    // Simulate DB transaction
    db.createLoan(app, 'Officer-X', remarks);
    setData(db.get()); // Refresh all data
  };

  const handleRejectLoan = (appId: string, reason: string) => {
    const app = data.applications.find(a => a.Application_ID === appId);
    if (!app) return;

    db.rejectLoan(app, 'Officer-X', reason);
    setData(db.get());
  };

  const handlePayEMI = (emiId: string, mode: 'UPI' | 'NetBanking' | 'Cash') => {
    // 1. Find EMI and Account
    const emi = data.emiSchedules.find(e => e.EMI_ID === emiId);
    if (!emi || emi.Payment_Status === 'Paid') return;

    // Double check balance, though gateway should have technically checked funds if it was real
    // For this simulation, we update the local ledger.
    if (data.bankAccount.Balance < emi.EMI_Amount) {
      alert("Insufficient Balance in linked account for final settlement!");
      return;
    }

    // 2. Create Payment Record
    const payment = {
      Payment_ID: `PAY-${Date.now()}`,
      EMI_ID: emi.EMI_ID,
      Payment_Date: new Date().toISOString().split('T')[0],
      Amount_Paid: emi.EMI_Amount,
      Payment_Mode: mode,
      Payment_Status: 'Success' as const
    };

    // 3. Update EMI Status
    const updatedEMIs = data.emiSchedules.map(e => 
      e.EMI_ID === emiId ? { ...e, Payment_Status: 'Paid' as const } : e
    );

    // 4. Update Balance
    const updatedAccount = {
      ...data.bankAccount,
      Balance: data.bankAccount.Balance - emi.EMI_Amount
    };

    const newData = db.update({
      emiSchedules: updatedEMIs,
      bankAccount: updatedAccount,
      payments: [...data.payments, payment]
    });
    
    setData(newData);
  };

  const toggleAdminMode = () => {
    setIsAdminMode(!isAdminMode);
    setCurrentView(isAdminMode ? 'DASHBOARD' : 'OFFICER_PORTAL');
  };

  // --- Rendering ---

  return (
    <Layout 
      currentView={currentView} 
      setView={setCurrentView}
      user={data.currentUser}
      isAdminMode={isAdminMode}
      toggleAdminMode={toggleAdminMode}
    >
      {currentView === 'DASHBOARD' && <Dashboard data={data} />}
      
      {currentView === 'APPLY_LOAN' && (
        <LoanApplicationForm data={data} onSubmit={handleCreateApplication} />
      )}
      
      {currentView === 'MY_LOANS' && (
        <MyLoans data={data} onPayEMI={handlePayEMI} />
      )}
      
      {currentView === 'OFFICER_PORTAL' && (
        <OfficerDashboard 
          data={data} 
          onApprove={handleApproveLoan}
          onReject={handleRejectLoan}
        />
      )}

      {currentView === 'PROFILE' && (
        <div className="bg-white p-8 rounded-xl shadow border border-slate-200 max-w-2xl">
           <h2 className="text-2xl font-bold mb-6">User Profile</h2>
           <div className="space-y-4">
             <div className="grid grid-cols-2 gap-4 border-b pb-4">
               <div><span className="text-slate-500 text-sm">Full Name</span><p className="font-medium">{data.currentUser.Full_Name}</p></div>
               <div><span className="text-slate-500 text-sm">Date of Birth</span><p className="font-medium">{data.currentUser.Date_of_Birth}</p></div>
             </div>
             <div className="grid grid-cols-2 gap-4 border-b pb-4">
               <div><span className="text-slate-500 text-sm">Email</span><p className="font-medium">{data.currentUser.Email}</p></div>
               <div><span className="text-slate-500 text-sm">Phone</span><p className="font-medium">{data.currentUser.Phone}</p></div>
             </div>
             <div className="grid grid-cols-2 gap-4">
               <div><span className="text-slate-500 text-sm">PAN Number</span><p className="font-mono bg-slate-100 p-1 rounded inline-block">{data.currentUser.PAN_Number}</p></div>
               <div><span className="text-slate-500 text-sm">Annual Income</span><p className="font-medium">${data.currentUser.Annual_Income.toLocaleString()}</p></div>
             </div>
           </div>
        </div>
      )}

      <AIAssistant data={data} />
    </Layout>
  );
}

export default App;