import { GoogleGenAI } from "@google/genai";
import { AppData } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialAdvice = async (
  prompt: string, 
  contextData: AppData
): Promise<string> => {
  const contextString = `
    User Context:
    Name: ${contextData.currentUser.Full_Name}
    Income: ${contextData.currentUser.Annual_Income}
    Credit Score: ${contextData.creditScore.Credit_Score_Value} (${contextData.creditScore.Credit_Rating})
    Bank Balance: ${contextData.bankAccount.Balance}
    Active Loans: ${contextData.loans.length}
    Pending Applications: ${contextData.applications.filter(a => a.Application_Status === 'Pending').length}
    
    The user is asking a question about their finances or the loan system.
    Be concise, professional, and act as a bank financial advisor.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `System: ${contextString}\n\nUser Question: ${prompt}`,
    });
    return response.text || "I couldn't generate a response at this time.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I am having trouble connecting to the financial brain currently. Please try again later.";
  }
};