import { 
  AppData, Customer, BankAccount, CreditScore, LoanType, 
  LoanApplication, Loan, EMISchedule, LoanApprovalLog 
} from '../types';
import { addMonths, format } from 'date-fns';

// --- Initial Seed Data ---

const INITIAL_CUSTOMER: Customer = {
  Customer_ID: 'CUST-001',
  Full_Name: 'Alex Mercer',
  Date_of_Birth: '1990-05-15',
  PAN_Number: 'ABCDE1234F',
  Aadhaar_Number: '1234-5678-9012',
  Email: 'alex.mercer@example.com',
  Phone: '+1-555-0102',
  Address: '123 Fintech Avenue, Silicon Valley',
  Employment_Type: 'Salaried',
  Annual_Income: 85000,
  Account_Status: 'Active',
};

const INITIAL_ACCOUNT: BankAccount = {
  Account_ID: 'ACC-998877',
  Customer_ID: 'CUST-001',
  Account_Number: '400012345678',
  Account_Type: 'Savings',
  Balance: 15250.00,
  IFSC_Code: 'FINC000123',
};

const INITIAL_CREDIT: CreditScore = {
  Credit_ID: 'CR-001',
  Customer_ID: 'CUST-001',
  Credit_Score_Value: 780,
  Credit_Rating: 'Excellent',
  Last_Updated: '2023-10-01',
};

const LOAN_TYPES: LoanType[] = [
  {
    Loan_Type_ID: 'LT-HOME',
    Loan_Name: 'Home Loan',
    Interest_Rate: 8.5,
    Max_Loan_Amount: 5000000,
    Min_Credit_Score: 700,
    Max_Tenure_Months: 240,
    Description: 'Purchase or construct your dream home.',
  },
  {
    Loan_Type_ID: 'LT-PERS',
    Loan_Name: 'Personal Loan',
    Interest_Rate: 12.0,
    Max_Loan_Amount: 1000000,
    Min_Credit_Score: 650,
    Max_Tenure_Months: 60,
    Description: 'Funds for travel, wedding, or medical emergencies.',
  },
  {
    Loan_Type_ID: 'LT-EDU',
    Loan_Name: 'Education Loan',
    Interest_Rate: 9.0,
    Max_Loan_Amount: 2000000,
    Min_Credit_Score: 600,
    Max_Tenure_Months: 120,
    Description: 'Invest in your future education.',
  },
];

// --- Logic Helpers ---

// Formula: E = P * r * (1+r)^n / ((1+r)^n - 1)
export const calculateEMI = (principal: number, annualRate: number, tenureMonths: number): number => {
  const monthlyRate = annualRate / 12 / 100;
  const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) / (Math.pow(1 + monthlyRate, tenureMonths) - 1);
  return Math.round(emi);
};

export const checkEligibility = (
  app: LoanApplication, 
  credit: CreditScore, 
  loanType: LoanType, 
  customer: Customer
): { eligible: boolean; reason?: string } => {
  
  // 1. Credit Score Check
  if (credit.Credit_Score_Value < loanType.Min_Credit_Score) {
    return { 
      eligible: false, 
      reason: `Credit Score (${credit.Credit_Score_Value}) is below the required minimum of ${loanType.Min_Credit_Score} for ${loanType.Loan_Name}.` 
    };
  }
  
  // 2. Max Loan Amount Check
  if (app.Requested_Amount > loanType.Max_Loan_Amount) {
    return { 
      eligible: false, 
      reason: `Requested Amount ($${app.Requested_Amount}) exceeds maximum limit of $${loanType.Max_Loan_Amount} for this loan type.` 
    };
  }

  // 3. Income vs EMI Check (Debt-to-Income Ratio)
  // Policy: EMI shouldn't exceed 50% of monthly income
  const potentialEMI = calculateEMI(app.Requested_Amount, loanType.Interest_Rate, app.Requested_Tenure);
  const monthlyIncome = customer.Annual_Income / 12;
  const maxAllowedEMI = monthlyIncome * 0.5;
  
  if (potentialEMI > maxAllowedEMI) {
    return { 
      eligible: false, 
      reason: `Affordability Check Failed: Estimated EMI ($${potentialEMI}) exceeds 50% of your monthly income ($${monthlyIncome.toFixed(0)}).` 
    };
  }

  return { eligible: true };
};

// --- Mock Payment Gateway Service ---
export const processPaymentWithGateway = async (amount: number, mode: string): Promise<{ success: boolean; message: string; transactionId?: string }> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate Payment Processing
      const isSuccess = Math.random() > 0.1; // 90% success rate
      
      if (isSuccess) {
        resolve({
          success: true,
          message: 'Transaction Successful',
          transactionId: `TXN-${Date.now()}-${Math.floor(Math.random()*1000)}`
        });
      } else {
        resolve({
          success: false,
          message: 'Transaction Failed: Bank Server Timeout'
        });
      }
    }, 2000); // 2 second delay to simulate API call
  });
};

// --- Mock Data Manager ---

class DataManager {
  private data: AppData;

  constructor() {
    this.data = {
      currentUser: INITIAL_CUSTOMER,
      bankAccount: INITIAL_ACCOUNT,
      creditScore: INITIAL_CREDIT,
      loanTypes: LOAN_TYPES,
      applications: [],
      loans: [],
      emiSchedules: [],
      payments: [],
      approvalLogs: []
    };
  }

  get() { return this.data; }

  // Simulate updating state (in a real app this would be backend calls)
  update(newData: Partial<AppData>) {
    this.data = { ...this.data, ...newData };
    return this.data;
  }

  createLoan(application: LoanApplication, approvedBy: string, remarks: string) {
    const loanType = this.data.loanTypes.find(lt => lt.Loan_Type_ID === application.Loan_Type_ID)!;
    
    // 1. Create Approval Log
    const log: LoanApprovalLog = {
      Approval_ID: `LOG-${Date.now()}`,
      Application_ID: application.Application_ID,
      Approved_By: approvedBy,
      Approval_Date: new Date().toISOString().split('T')[0],
      Decision: 'Approved',
      Remarks: remarks
    };

    // 2. Update Application Status
    const updatedApps = this.data.applications.map(app => 
      app.Application_ID === application.Application_ID 
      ? { ...app, Application_Status: 'Approved' as const } 
      : app
    );

    // 3. Create Loan
    const loan: Loan = {
      Loan_ID: `LOAN-${Math.floor(Math.random() * 10000)}`,
      Application_ID: application.Application_ID,
      Customer_ID: application.Customer_ID,
      Loan_Type_ID: application.Loan_Type_ID,
      Approved_Amount: application.Requested_Amount,
      Interest_Rate: loanType.Interest_Rate,
      Tenure_Months: application.Requested_Tenure,
      Loan_Start_Date: new Date().toISOString().split('T')[0],
      Loan_End_Date: format(addMonths(new Date(), application.Requested_Tenure), 'yyyy-MM-dd'),
      Loan_Status: 'Active'
    };

    // 4. Generate EMI Schedule
    const emiAmount = calculateEMI(loan.Approved_Amount, loan.Interest_Rate, loan.Tenure_Months);
    const newEMIs: EMISchedule[] = [];
    
    for (let i = 1; i <= loan.Tenure_Months; i++) {
      newEMIs.push({
        EMI_ID: `EMI-${loan.Loan_ID}-${i}`,
        Loan_ID: loan.Loan_ID,
        EMI_Number: i,
        EMI_Amount: emiAmount,
        Due_Date: format(addMonths(new Date(), i), 'yyyy-MM-dd'),
        Payment_Status: 'Pending'
      });
    }

    // Update Store
    this.data = {
      ...this.data,
      applications: updatedApps,
      approvalLogs: [...this.data.approvalLogs, log],
      loans: [...this.data.loans, loan],
      emiSchedules: [...this.data.emiSchedules, ...newEMIs],
      bankAccount: { 
        ...this.data.bankAccount, 
        Balance: this.data.bankAccount.Balance + loan.Approved_Amount 
      } // Disburse money
    };
  }

  rejectLoan(application: LoanApplication, rejectedBy: string, reason: string) {
      // 1. Create Approval Log
      const log: LoanApprovalLog = {
        Approval_ID: `LOG-${Date.now()}`,
        Application_ID: application.Application_ID,
        Approved_By: rejectedBy,
        Approval_Date: new Date().toISOString().split('T')[0],
        Decision: 'Rejected',
        Remarks: reason
      };
  
      // 2. Update Application Status
      const updatedApps = this.data.applications.map(app => 
        app.Application_ID === application.Application_ID 
        ? { ...app, Application_Status: 'Rejected' as const, Rejection_Reason: reason } 
        : app
      );

      this.data = {
          ...this.data,
          applications: updatedApps,
          approvalLogs: [...this.data.approvalLogs, log]
      };
  }
}

export const db = new DataManager();